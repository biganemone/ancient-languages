"""Export some works from the app's texts database as a standalone module file.

  python export_module.py <texts_app.db> <out.db> [--urn URN ...] [--author NAME ...] [--language CODE ...]

A first step towards downloadable modules (claude/app-size-and-modules.md):
it shows that a module is a query over the compact database, and gives a
realistic size for each candidate grouping. The output has the app schema
(compact_texts.SCHEMA) with only the chosen works and what they refer to:

  - work, part, block, segment, token, morph rows of those works
    (tokens are numbered per work: work.token_first..token_last);
  - the lemma, tag and parse rows they use (ids kept; an importer matches
    lemmas by key and renumbers);
  - Morpheus analyses for the word forms that occur in them;
  - parallel-map rows whose either side is one of them (by URN, so the other
    side need not be installed).

Selecting nothing exports nothing. Prints the module's size and contents.
"""
import argparse
import os
import sqlite3

import compact_texts


def chunks(ids, n=900):
    ids = list(ids)
    for i in range(0, len(ids), n):
        yield ids[i:i + n]


def copy_rows(s, d, table, column, ids):
    cols = [r[1] for r in s.execute(f"PRAGMA table_info({table})")]
    marks = ",".join("?" * len(cols))
    for part in chunks(sorted(ids)):
        q = ",".join("?" * len(part))
        d.executemany(f"INSERT INTO {table} VALUES ({marks})",
                      s.execute(f"SELECT * FROM {table} WHERE {column} IN ({q})", part))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("db")
    ap.add_argument("out")
    ap.add_argument("--urn", action="append", default=[])
    ap.add_argument("--author", action="append", default=[])
    ap.add_argument("--language", action="append", default=[], help="lat, cop, or grc (no language set)")
    a = ap.parse_args()

    s = sqlite3.connect(a.db)
    works = []
    for wid, urn, author, lang in s.execute("SELECT id, urn, author, COALESCE(language, 'grc') FROM work"):
        if urn in a.urn or author in a.author or lang in a.language:
            works.append(wid)
    if os.path.exists(a.out):
        os.remove(a.out)
    d = sqlite3.connect(a.out)
    d.executescript(compact_texts.SCHEMA)
    d.execute("CREATE TABLE parallel (urn TEXT, cite TEXT, other_urn TEXT, other_cite TEXT)")

    copy_rows(s, d, "work", "id", works)
    for table in ("part", "block", "segment"):
        copy_rows(s, d, table, "work_id", works)

    ranges = s.execute(f"SELECT token_first, token_last FROM work WHERE id IN ({','.join('?' * len(works))})",
                       works).fetchall() if works else []
    lemmas, tags, forms = set(), set(), set()
    texts = dict(d.execute("SELECT id, text FROM segment"))
    for first, last in ranges:
        if first is None:
            continue
        rows = s.execute("SELECT * FROM token WHERE id BETWEEN ? AND ?", (first, last)).fetchall()
        d.executemany(f"INSERT INTO token VALUES ({','.join('?' * len(rows[0]))})", rows) if rows else None
        for tid, seg, idx, start, length, lid, tag, source, word, form, aor in rows:
            lemmas.update(x for x in (lid, aor) if x)
            if tag:
                tags.add(tag)
            forms.add(form or compact_texts.u16_slice(texts[seg], start, start + length))
        morphs = s.execute("SELECT * FROM morph WHERE token_id BETWEEN ? AND ?", (first, last)).fetchall()
        d.executemany("INSERT INTO morph VALUES (?,?,?,?,?)", morphs)
        for _, _, _, lid, tag in morphs:
            if lid:
                lemmas.add(lid)
            if tag:
                tags.add(tag)

    # the Morpheus analyses of the forms that occur (looked up as written and lowercased)
    forms |= {f.lower() for f in forms}
    parses = set()
    for part in chunks(sorted(forms)):
        q = ",".join("?" * len(part))
        rows = s.execute(f"SELECT * FROM analysis WHERE form IN ({q})", part).fetchall()
        d.executemany("INSERT INTO analysis VALUES (?,?,?,?)", rows)
        for _, _, lid, pid in rows:
            lemmas.add(lid)
            parses.add(pid)
    # an aorist's lemma row points at its verb
    lemmas |= {b for (b,) in s.execute(
        f"SELECT base_id FROM lemma WHERE kind = 1 AND id IN ({','.join(map(str, lemmas)) or 'NULL'})") if b}
    copy_rows(s, d, "lemma", "id", lemmas)
    copy_rows(s, d, "tag", "id", tags)
    copy_rows(s, d, "parse", "id", parses)

    urns = [u for (u,) in d.execute("SELECT urn FROM work")]
    for part in chunks(urns):
        q = ",".join("?" * len(part))
        d.executemany("INSERT INTO parallel VALUES (?,?,?,?)",
                      s.execute(f"SELECT * FROM parallel WHERE urn IN ({q}) OR other_urn IN ({q})", part + part))

    d.executescript(compact_texts.INDEXES)
    d.execute("CREATE INDEX parallel_urn ON parallel(urn)")
    d.execute("CREATE INDEX block_cite ON block(work_id, cite_start)")
    d.commit()
    d.execute("VACUUM")
    counts = {t: d.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
              for t in ("work", "segment", "token", "lemma", "analysis", "parallel")}
    d.close()
    print(f"{a.out}: {os.path.getsize(a.out) / 1e6:.1f} MB", counts)


if __name__ == "__main__":
    main()
