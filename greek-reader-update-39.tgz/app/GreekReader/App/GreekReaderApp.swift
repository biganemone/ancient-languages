import SwiftUI

@main
struct GreekReaderApp: App {
    @State private var library = Library.load()
    @State private var catalog = Catalog.load()

    init() {
        Fonts.registerBundledFonts()
    }

    var body: some Scene {
        WindowGroup {
            RootView(library: library, catalog: catalog)
                .environment(AnnotationStore.shared)
                .environment(StudyStore.shared)
        }
    }
}

/// Two tabs, Read and Study; the app opens on whichever was used last.
struct RootView: View {
    let library: Library
    let catalog: Catalog

    @AppStorage(SettingsKey.rootTab) private var tab = RootTab.read

    var body: some View {
        TabView(selection: $tab) {
            LibraryView(library: library, catalog: catalog)
                .tabItem { Label("Read", systemImage: "book") }
                .tag(RootTab.read)
            StudyTab(library: library)
                .tabItem { Label("Study", systemImage: "rectangle.stack") }
                .tag(RootTab.study)
        }
    }
}

/// The Study tab: the flashcard decks.
struct StudyTab: View {
    let library: Library

    var body: some View {
        NavigationStack {
            List {
                StudyHomeView(library: library)
            }
            .navigationTitle("Study")
            .navigationDestination(for: StudyRoute.self) { route in
                switch route {
                case .session(let id):
                    StudySessionView(deckID: id, library: library)
                        .toolbar(.hidden, for: .tabBar)
                }
            }
        }
    }
}

/// Opens the bundled databases once and shares them.
struct Library {
    let texts: TextStore?
    let lexicon: LexiconStore?
    let works: [Work]
    let problem: String?

    static func load() -> Library {
        guard let textsURL = Bundle.main.url(forResource: "texts", withExtension: "db"),
              let lexiconURL = Bundle.main.url(forResource: "lexicon", withExtension: "db") else {
            return Library(texts: nil, lexicon: nil, works: [],
                           problem: "The databases aren't in the app bundle yet. Run pipeline/build.sh, then build again in Xcode.")
        }
        do {
            let texts = try TextStore(url: textsURL)
            let lexicon = try LexiconStore(url: lexiconURL)
            return Library(texts: texts, lexicon: lexicon, works: try texts.works(), problem: nil)
        } catch {
            return Library(texts: nil, lexicon: nil, works: [], problem: "\(error)")
        }
    }
}
