import Foundation

/// Every text the project offers, installed or not (Resources/Databases/catalog.json,
/// written by pipeline/make_catalog.py from the full build). The app ships some of
/// them; the rest will come as downloads (claude/app-size-and-modules.md).
struct Catalog {
    struct Entry: Codable, Identifiable, Hashable {
        let urn: String
        let language: String
        let author: String
        let title: String
        let translator: String
        let scope: String
        let words: Int              // tokens, to give an idea of size
        let bytes: Int?             // approximate download size, once modules exist
        var id: String { urn }
    }

    private struct File: Codable {
        let version: Int
        let works: [Entry]
    }

    let entries: [Entry]

    static func load() -> Catalog {
        guard let url = Bundle.main.url(forResource: "catalog", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let file = try? JSONDecoder().decode(File.self, from: data) else {
            return Catalog(entries: [])
        }
        return Catalog(entries: file.works)
    }

    /// Entries not in the library, optionally for one language and/or author (group).
    func missing(from works: [Work], language: LibraryLanguage? = nil, author: String? = nil) -> [Entry] {
        let installed = Set(works.map(\.urn))
        return entries.filter { e in
            !installed.contains(e.urn)
                && (language == nil || LibraryLanguage(code: e.language) == language)
                && (author == nil || e.author == author)
        }
    }

    /// Languages the catalog offers that have nothing installed yet (for "Add languages").
    func languagesNotInstalled(works: [Work]) -> [LibraryLanguage] {
        let have = Set(works.compactMap { LibraryLanguage(code: $0.language) })
        let offered = Set(entries.compactMap { LibraryLanguage(code: $0.language) })
        return LibraryLanguage.allCases.filter { offered.contains($0) && !have.contains($0) }
    }
}
