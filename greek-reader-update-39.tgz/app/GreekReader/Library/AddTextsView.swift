import SwiftUI

/// "Add Texts": every catalogued text not yet in the library, by language and
/// author, optionally narrowed to one language or one author's group.
/// Downloading is not built yet; choosing a text says so.
struct AddTextsView: View {
    let catalog: Catalog
    let works: [Work]
    var language: LibraryLanguage? = nil
    var author: String? = nil

    @Environment(\.dismiss) private var dismiss
    @State private var chosen: Catalog.Entry?

    private var missing: [Catalog.Entry] { catalog.missing(from: works, language: language, author: author) }

    var body: some View {
        NavigationStack {
            List {
                if missing.isEmpty {
                    ContentUnavailableView {
                        Label("You have them all", systemImage: "checkmark.circle")
                    } description: {
                        Text(author.map { "Every text by or in \($0) is already in your library." }
                             ?? language.map { "Every \($0.label) text is already in your library." }
                             ?? "Every available text is already in your library.")
                    }
                    .listRowBackground(Color.clear)
                } else {
                    ForEach(groups, id: \.key) { group in
                        Section(group.key) {
                            ForEach(group.entries) { entry in
                                Button { chosen = entry } label: { row(entry) }
                                    .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            .navigationTitle(author ?? language.map { "Add \($0.label) Texts" } ?? "Add Texts")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
            .alert(chosen?.title ?? "", isPresented: Binding(get: { chosen != nil }, set: { if !$0 { chosen = nil } })) {
                Button("OK", role: .cancel) { chosen = nil }
            } message: {
                Text("Downloading texts isn't available yet. It's coming in a later version.")
            }
        }
    }

    private func row(_ e: Catalog.Entry) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(e.title).font(.headline)
                Text([e.scope == "complete" ? nil : e.scope,
                      e.translator.isEmpty ? nil : "English: \(e.translator)",
                      "\(e.words.formatted()) words"].compactMap { $0 }.joined(separator: " · "))
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "arrow.down.circle").foregroundStyle(Color.accentColor)
        }
        .contentShape(Rectangle())
    }

    /// "Greek · Plato", in the catalog's order
    private var groups: [(key: String, entries: [Catalog.Entry])] {
        var order: [String] = []
        var by: [String: [Catalog.Entry]] = [:]
        for e in missing {
            let lang = LibraryLanguage(code: e.language)?.label ?? e.language
            let key = language == nil ? "\(lang) · \(e.author)" : e.author
            if by[key] == nil { order.append(key) }
            by[key, default: []].append(e)
        }
        return order.map { ($0, by[$0] ?? []) }
    }
}
