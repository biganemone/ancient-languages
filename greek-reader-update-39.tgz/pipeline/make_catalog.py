"""Write the catalog of every text the project offers (the full build's
works), which the app shows under "Add Texts" for those it doesn't have.

  python make_catalog.py <texts_app.db (full)> <catalog.json>

Each entry: urn, language, author (or group), title, translator, scope and
word count. `bytes` (the download size) is filled in once modules are built."""
import json
import sqlite3
import sys


def main(db_path, out):
    db = sqlite3.connect(db_path)
    works = []
    for urn, lang, author, title, translator, scope, first, last in db.execute(
            "SELECT urn, COALESCE(NULLIF(language, ''), 'grc'), author, title, translator, scope, token_first, "
            "token_last FROM work ORDER BY sort"):
        words = (last - first + 1) if first is not None and last is not None else 0
        works.append(dict(urn=urn, language=lang, author=author, title=title, translator=translator or "",
                          scope=scope or "complete", words=words, bytes=None))
    with open(out, "w", encoding="utf-8") as f:
        json.dump(dict(version=1, works=works), f, ensure_ascii=False, indent=0)
    print(f"{out}: {len(works)} works")


if __name__ == "__main__":
    main(*sys.argv[1:3])
