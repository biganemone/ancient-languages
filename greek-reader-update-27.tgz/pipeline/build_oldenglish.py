"""Old English texts: Beowulf.

  python build_oldenglish.py <sources> <texts.db>

Beowulf: Klaeber's text (1922) and James M. Garnett's line-for-line
translation (1882), both from the Perseus Digital Library (canonical-angLit,
CC BY-SA). Lemmas and parses come from Klaeber's own glossary, which cites
nearly every word of the poem by line (see oldenglish.py): a hand-made,
in-context analysis. Words the glossary cites only by count ("ond … 311
times") get their lemma from their form.

Blocks are sentences of the poem (ending in . ; ! ?), 2–12 lines, never across
a fitt, each with Garnett's lines of the same numbers.
"""
import json
import re
import sqlite3
import sys
from collections import Counter

from lxml import etree

import oldenglish as oe

TEI = oe.TEI
CAESURA = "  "         # the gap between half-lines
CREDIT = ("Text: Fr. Klaeber, Beowulf (1922); translation: James M. Garnett (1882); glossary: Klaeber's, "
          "from which the lemmas and parses are taken. All from the Perseus Digital Library (CC BY-SA). "
          "Bosworth–Toller's Anglo-Saxon Dictionary (1898, 1921; public domain) from the Germanic Lexicon "
          "Project.")


def u16(text, i):
    return len(text[:i].encode("utf-16-le")) // 2


def line_text(el):
    parts = [el.text or ""]
    for c in el:
        name = c.tag.split("}")[-1] if isinstance(c.tag, str) else ""
        if name == "seg" and c.get("type") == "caesura":
            parts.append(CAESURA)
        else:
            parts.append("".join(c.itertext()))
        parts.append(c.tail or "")
    text = "".join(parts)
    text = re.sub(r"[ \t\n]+", " ", text)
    text = re.sub(r" ?   ?", CAESURA, text)
    return text.replace(" !", "!").replace(" ?", "?").replace(" ;", ";").strip()


def poem(path):
    """[(n, text, fitt heading or None)]"""
    root = etree.parse(path).getroot()
    out = []
    for card in root.iter(TEI + "div"):
        if card.get("subtype") != "card":
            continue
        head = card.find(TEI + "head")
        heading = "".join(head.itertext()).strip() if head is not None else None
        if heading and heading != "Prologue":
            heading = f"Fitt {heading}"
        for k, l in enumerate(card.iter(TEI + "l")):
            out.append((int(l.get("n")), line_text(l), heading if k == 0 else None))
    return out


def translation(path):
    """{line number: text}: Garnett's lines, numbered from each card's start
    and re-synchronised at his own numbers (every fifth line)."""
    root = etree.parse(path).getroot()
    out = {}
    for card in root.iter(TEI + "div"):
        if card.get("subtype") != "card":
            continue
        n = int(card.get("n"))
        for l in card.iter(TEI + "l"):
            if l.get("n") and l.get("n").isdigit() and abs(int(l.get("n")) - n) <= 10:
                n = int(l.get("n"))          # (ignoring misprints: "8025" for 3025)
            text = " ".join("".join(l.itertext()).split())
            if n in out:                     # an extra line in the translation: keep it with the last
                out[n] += " " + text
            else:
                out[n] = text
            n += 1
    return out


def blocks(lines, english):
    out, cur = [], []
    for k, (n, text, heading) in enumerate(lines):
        if heading and cur:
            out.append(cur)
            cur = []
        cur.append((n, text, heading))
        end = re.search(r"[.;!?]['’]?\s*$", text)
        nxt_heading = k + 1 < len(lines) and lines[k + 1][2]
        if (end and len(cur) >= 2) or len(cur) >= 12 or nxt_heading:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return [dict(cite_start=str(b[0][0]), cite_end=str(b[-1][0]),
                 english="\n".join(english.get(n, "") for n, _, _ in b).strip(), lines=b) for b in out]


def build_beowulf(db, sources, sort):
    base = f"{sources}/canonical-angLit/data/anon"
    lines = poem(f"{base}/beowulf/anon.beowulf.perseus-ang1.xml")
    english = translation(f"{base}/beowulf/anon.beowulf.perseus-eng1.xml")
    toks = {n: oe.tokenize(text) for n, text, _ in lines}
    words = {oe.form_key(w) for ts in toks.values() for _, _, w in ts}
    glossary = oe.Glossary(f"{base}/klaeber_glossary/anon.klaeber_glossary.perseus-mul1.xml", words)
    analysis = oe.lemmatise({n: [w for _, _, w in ts] for n, ts in toks.items()}, glossary)

    wid = db.execute(
        "INSERT INTO work(sort,urn,author,title,kind,form,greek_urn,english_urn,translator,scope,parse_source,"
        "language,credit) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (sort, "urn:cts:angLit:anon.beowulf", "Beowulf", "Beowulf", "verse", "epic",
         "urn:cts:angLit:anon.beowulf.perseus-ang1", "urn:cts:angLit:anon.beowulf.perseus-eng1",
         "James M. Garnett", "complete", "treebank", "ang", CREDIT)).lastrowid
    stats = Counter()
    seq = 0
    bl = blocks(lines, english)
    for bi, b in enumerate(bl):
        bid = db.execute("INSERT INTO block(work_id,seq,cite_start,cite_end,english,english_markers)"
                         " VALUES (?,?,?,?,?,?)", (wid, bi, b["cite_start"], b["cite_end"], b["english"], "[]")).lastrowid
        for k, (n, text, heading) in enumerate(b["lines"]):
            sid = db.execute(
                "INSERT INTO segment(work_id,block_id,seq,cite,line_n,speaker,heading,part,para_start,text,markers)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (wid, bid, seq, str(n), n, None, heading, None, 1 if heading else 0, text, "[]")).lastrowid
            seq += 1
            for idx, ((s, e, form), r) in enumerate(zip(toks[n], analysis[n])):
                lemma = key = tag = source = None
                if r:
                    i, tag, how = r
                    entry = glossary.entries[i]
                    lemma, key, source = oe.display_headword(entry["headword"]), entry["key"], "treebank"
                    stats[how] += 1
                else:
                    stats["none"] += 1
                db.execute('INSERT INTO token(segment_id,idx,start,"end",form,lemma,lemma_key,postag,source)'
                           " VALUES (?,?,?,?,?,?,?,?,?)",
                           (sid, idx, u16(text, s), u16(text, e), form, lemma, key, tag, source))
    total = sum(stats.values())
    return dict(lines=len(lines), blocks=len(bl), tokens=total,
                by_line=f"{100 * stats['line'] / total:.1f}%", by_form=f"{100 * stats['form'] / total:.1f}%",
                none=f"{100 * stats['none'] / total:.1f}%",
                english_lines=len(english), english_missing=sum(1 for n, _, _ in lines if n not in english))


def main(sources, out):
    db = sqlite3.connect(out)
    sort = db.execute("SELECT COALESCE(MAX(sort), 0) FROM work").fetchone()[0] + 1
    report = {"Beowulf": build_beowulf(db, sources, sort)}
    db.commit()
    print(json.dumps(report, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main(*sys.argv[1:3])
