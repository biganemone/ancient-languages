import SwiftUI

struct LibraryView: View {
    let library: Library

    @AppStorage(SettingsKey.libraryLanguage) private var language = LibraryLanguage.greek
    /// Authors whose lists are open ("\n"-separated); all are closed at first.
    @AppStorage(SettingsKey.expandedAuthors) private var expandedStore = ""
    @State private var query = ""

    private var searching: Bool { !query.trimmingCharacters(in: .whitespaces).isEmpty }
    private var expanded: Set<String> { Set(expandedStore.split(separator: "\n").map(String.init)) }

    var body: some View {
        NavigationStack {
            List {
                if let problem = library.problem {
                    Section {
                        Label(problem, systemImage: "exclamationmark.triangle")
                            .foregroundStyle(.secondary)
                    }
                }
                if !searching {
                    // segments while they fit; a menu once there are many languages
                    Group {
                        if shelves.count <= 4 {
                            shelfPicker.pickerStyle(.segmented)
                        } else {
                            shelfPicker.pickerStyle(.menu)
                        }
                    }
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets())
                }
                if shownLanguage == .study && !searching {
                    StudyHomeView(library: library)
                }
                if searching && groupedByAuthor.isEmpty {
                    ContentUnavailableView.search(text: query)
                        .listRowBackground(Color.clear)
                }
                ForEach(groupedByAuthor) { group in
                    if group.works.count == 1 && !searching, let work = group.works.first {
                        // one work: no list to open, just the work
                        Section {
                            workRow(work, showAuthor: true)
                        }
                    } else {
                        let open = searching || expanded.contains(group.author)
                        Section {
                            if open {
                                ForEach(group.works) { workRow($0, showAuthor: false) }
                            }
                        } header: {
                            authorHeader(group, open: open)
                        }
                    }
                }
                if shownLanguage != .study && !searching {
                    Section {
                        Text(shownLanguage == .greek ? Self.greekCredits
                             : shownLanguage == .latin ? Self.latinCredits
                             : shownLanguage == .oldEnglish ? Self.oldEnglishCredits
                             : shownLanguage == .hebrew ? Self.hebrewCredits
                             : shownLanguage == .sanskrit ? Self.sanskritCredits : Self.copticCredits)
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .searchable(text: $query, prompt: "Search titles and authors")
            .navigationTitle("Greek Reader")
            .navigationDestination(for: Work.self) { work in
                ReaderView(work: work, library: library)
            }
            .navigationDestination(for: StudyRoute.self) { route in
                switch route {
                case .session(let id): StudySessionView(deckID: id, library: library)
                }
            }
        }
    }

    private static let greekCredits = "Texts, translations and treebank from the Perseus Digital Library, Tufts University (CC BY-SA). Treebanks of Plato's Apology and Crito, Thucydides and Josephus from Vanessa Gorman's Greek dependency treebanks (CC BY-SA). LSJ, Middle Liddell and short definitions in the Logeion editions by Helma Dik (CC BY-SA). Autenrieth's Homeric Dictionary from the Perseus Digital Library (CC BY-SA). Septuagint: Swete's text as transcribed by the First1KGreek project (CC BY-SA 4.0), parsed automatically with Morpheus, with the Updated Brenton English Septuagint (CC0). New Testament: the SBL Greek New Testament (Society of Biblical Literature and Logos Bible Software, CC BY 4.0), with lemmas and morphology from the MACULA Greek Linguistic Datasets (Biblica, CC BY 4.0), the Berean Standard Bible (public domain) and Abbott-Smith's Manual Greek Lexicon of the New Testament (public domain). Gentium Book Plus by SIL (OFL)."
    private static let latinCredits = "Aeneid: text (Greenough) and translation (Theodore C. Williams) from the Perseus Digital Library (CC BY-SA), parsed with the Perseus Latin Dependency Treebank (6.1–295) and Morpheus. Vulgate: the Clementine Vulgate and the Douay-Rheims Bible (Challoner), public domain; parses from the PROIEL treebank of Jerome's Vulgate (Dag Haug et al., CC BY-NC-SA 4.0) for most of the New Testament, Morpheus elsewhere. Lewis & Short's Latin Dictionary, Lewis's Elementary Latin Dictionary and short definitions from the Perseus Digital Library and Logeion (Helma Dik) (CC BY-SA)."
    private static let copticCredits = "Gospel of Thomas: text and annotation from Coptic SCRIPTORIUM (CC BY). Nag Hammadi and Berlin Codex texts and Crum's Coptic Dictionary from Marcion by Milan Konvička (GPL), analysed automatically with the Coptic SCRIPTORIUM NLP tools. Sahidic New Testament: Sahidic Bible 2 (Christian Askeland, Matthias Schulz; INTF Münster), CC BY-SA, transcribing the principal manuscripts, with the verses they lack from G. W. Horner's edition (1911–24, public domain), analysed automatically with the Coptic SCRIPTORIUM NLP tools; English from the Berean Standard Bible. Comprehensive Coptic Lexicon by BBAW and DDGLC via KELLIA (CC BY-SA). Noto Sans Coptic by Google (OFL)."

    private static let oldEnglishCredits = "Beowulf: Fr. Klaeber's text (1922) and glossary, and James M. Garnett's translation (1882), from the Perseus Digital Library (CC BY-SA); lemmas and parses taken from Klaeber's glossary. The other poems: The Anglo-Saxon Poetic Records, ed. G. P. Krapp and E. V. K. Dobbie, in Greg Hidley's electronic text (Oxford Text Archive, CC BY-SA), as collected by the Classical Language Toolkit; lemmas and parses automatic, from Beowulf and Ondřej Tichý's Old English morphological generator (CC BY 4.0). English, from Project Gutenberg (public domain): Cosette Faust and Stith Thompson, Old English Poems (1918); James M. Garnett, Elene, Judith, Brunanburh, Maldon and The Dream of the Rood (1889); Robert Kilburn Root, Andreas (1899); James Hall Pitman, The Old English Physiologus (1921). Bosworth and Toller's Anglo-Saxon Dictionary (1898) and Supplement (1921), public domain, from the Germanic Lexicon Project, as assembled by Madeleine Thompson's btc_anglo_saxon (MIT). Gentium Book Plus by SIL (OFL)."

    private var shelfPicker: some View {
        Picker("Shelf", selection: $language) {
            ForEach(shelves) { Text($0.label).tag($0) }
        }
    }

    private static let hebrewCredits = "Hebrew Bible: the Westminster Leningrad Codex (public domain), with lemmas and morphology from the Open Scriptures Hebrew Bible (CC BY 4.0); Brown–Driver–Briggs and Strong's dictionaries from the Open Scriptures Hebrew Lexicon (CC BY 4.0; text public domain); short definitions from STEPBible's Translators Brief Lexicon (TBESH, CC BY 4.0); English from the Berean Standard Bible (public domain). Noto Serif Hebrew by Google (OFL)."

    private static let sanskritCredits = "Bhagavad Gītā: text, lemmas and analyses from the Digital Corpus of Sanskrit by Oliver Hellwig (CC BY 4.0), the critical edition's text; verse numbers from the gita/gita dataset (the Unlicense); English: Annie Besant's translation (4th edition, 1922; public domain), from Wikisource. Upaniṣads: text, lemmas and analyses from the Digital Corpus of Sanskrit (CC BY 4.0); sections numbered from the mūla text of Śaṅkara's commentaries (GRETIL) and from Sanskrit Wikisource, which also supply the few passages DCS lacks (shown unanalysed); English: F. Max Müller, The Upanishads (Sacred Books of the East 1 and 15, 1879–84; public domain), from sacred-texts.com. Macdonell's Practical Sanskrit Dictionary (1893) and Monier-Williams's Sanskrit-English Dictionary (1899) from the Cologne Digital Sanskrit Dictionaries (CC BY-SA 4.0); short definitions from the Digital Corpus of Sanskrit. Gentium Book Plus by SIL (OFL)."

    /// Greek, Coptic (when there are Coptic texts) and Study.
    private var shelves: [LibraryLanguage] {
        LibraryLanguage.allCases.filter {
            ($0 != .coptic || library.works.contains(where: \.isCoptic))
                && ($0 != .latin || library.works.contains(where: \.isLatin))
                && ($0 != .oldEnglish || library.works.contains(where: \.isOldEnglish))
                && ($0 != .hebrew || library.works.contains(where: \.isHebrew))
                && ($0 != .sanskrit || library.works.contains(where: \.isSanskrit))
        }
    }

    private var shownLanguage: LibraryLanguage {
        shelves.contains(language) ? language : .greek
    }

    private func workRow(_ work: Work, showAuthor: Bool) -> some View {
        NavigationLink(value: work) {
            VStack(alignment: .leading, spacing: 2) {
                Text(showAuthor && work.author != work.title ? "\(work.author), \(work.title)" : work.title)
                    .font(.headline)
                Text(subtitle(work))
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    /// Tap to open or close an author's list.
    private func authorHeader(_ group: AuthorGroup, open: Bool) -> some View {
        Button {
            guard !searching else { return }
            var set = expanded
            if open { set.remove(group.author) } else { set.insert(group.author) }
            withAnimation(.easeInOut(duration: 0.2)) {
                expandedStore = set.sorted().joined(separator: "\n")
            }
        } label: {
            HStack {
                Text(group.author)
                Spacer()
                Text("\(group.works.count)").monospacedDigit()
                Image(systemName: "chevron.right")
                    .rotationEffect(.degrees(open ? 90 : 0))
                    .font(.caption.weight(.semibold))
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityHint(open ? "Hides the works" : "Shows the works")
    }

    private func subtitle(_ work: Work) -> String {
        if work.isCoptic {
            if work.isBible { return "Sahidic Bible 2 · English: \(work.translator)" }
            return work.parseSource == "scriptorium" ? "Coptic SCRIPTORIUM edition"
                                                     : "Text from Marcion · automatic analysis"
        }
        if work.isOldEnglish && work.translator.isEmpty {
            return "Text of the Anglo-Saxon Poetic Records · automatic analysis"
        }
        return work.scope == "complete" ? "English: \(work.translator)"
                                        : "\(work.scope) · English: \(work.translator)"
    }

    private struct AuthorGroup: Identifiable {
        let author: String
        let works: [Work]
        var id: String { author }
    }

    private var groupedByAuthor: [AuthorGroup] {
        var order: [String] = []
        var groups: [String: [Work]] = [:]
        let q = query.trimmingCharacters(in: .whitespaces)
        // A search looks through every shelf; otherwise, this shelf's works.
        let works: [Work]
        if q.isEmpty {
            guard shownLanguage != .study else { return [] }
            works = library.works.filter { w in
                switch shownLanguage {
                case .coptic: return w.isCoptic
                case .latin: return w.isLatin
                case .oldEnglish: return w.isOldEnglish
                case .hebrew: return w.isHebrew
                case .sanskrit: return w.isSanskrit
                default: return !w.isCoptic && !w.isLatin && !w.isOldEnglish && !w.isHebrew && !w.isSanskrit
                }
            }
        } else {
            works = library.works.filter { work in
                [work.title, work.author, work.translator].contains { field in
                    field.range(of: q, options: [.caseInsensitive, .diacriticInsensitive]) != nil
                }
            }
        }
        for work in works {
            if groups[work.author] == nil { order.append(work.author) }
            groups[work.author, default: []].append(work)
        }
        return order.map { AuthorGroup(author: $0, works: groups[$0] ?? []) }
    }
}
